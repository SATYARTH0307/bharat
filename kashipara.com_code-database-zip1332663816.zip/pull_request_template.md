# please take some beginner tutorial before getting started onto google colab
# ignore mounitng drive onto colab if not working on it.
